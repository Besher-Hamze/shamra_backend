import { Controller } from '@nestjs/common';

@Controller('files')
export class FilesController {}
